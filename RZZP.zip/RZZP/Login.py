from selenium import webdriver
# from time import sleep
import time
import unittest
from redmine_page import Login, MenuPage
from HTMLTestRunner import HTMLTestRunner
from send_email import new_report, send_mail

class LoginTest(unittest.TestCase):
    '''人资招聘系统自动化'''
    @classmethod
    def setUpClass(self):
        self.driver = webdriver.Firefox()
        self.driver.maximize_window()
        self.driver.get('http://10.1.27.52:9011/module-operation!executeOperation?operation=Form&componentCode=vp_hr_recruitment_web&windowCode=login')
        self.driver.implicitly_wait(20)

    @classmethod
    def tearDownClass(self):
        self.driver.quit()

   # @unittest.skip("测试跳过")
    def test_01_login(self):
        '''用例1：检查登录系统是否成功'''
        loginpage = Login(self.driver)  # 实例化登录页面对象
        ele = loginpage.user_login()
        self.assertEqual("同望招聘系统-登录",ele)

    #@unittest.skip("测试跳过")
    def test_02_menu(self):
        '''用例2：检查二级菜单是否丢失'''
        mark = MenuPage(self.driver)# 实例化登录页面对象,继承basepage所以需要传递参数driver
        remark = mark.menu_butten()
        self.assertEqual(1,remark)

if __name__ == '__main__':
    # unittest.main()
    suite = unittest.TestSuite()
    suite.addTests(unittest.TestLoader().loadTestsFromTestCase(LoginTest))
    report_dir = 'D:\\py\\Test_Page\\RZZP\\report'
    # report_dir = './report'
    now = time.strftime("%Y-%m-%d %H-%M-%S")
    report_name = report_dir + '/' + now + 'result.html'
    with open(report_name, 'wb') as f:
        runner = HTMLTestRunner(stream=f, title="招聘系统", description="用例详情")
        runner.run(suite)
    latest_report = new_report(report_dir)
    send_mail('jiangyujing@toone.com.cn,wangls@toone.com.cn',latest_report)

    # suite = unittest.TestSuite()
    # suite.addTest(LoginTest("test_01_login"))
    # run = unittest.TextTestRunner()
    #
    #
    # f = open("./baidu.html","wb")
    # run = HTMLTestRunner(
    #     stream=f,
    #     title="baogao",
    # )
    # run.run(suite)

