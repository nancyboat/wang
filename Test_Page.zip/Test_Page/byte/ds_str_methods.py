name = 'Swaroop'
if name.startswith('Swa'):
    print('Yes,the string starts with')