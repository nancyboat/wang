import os
import platform
import logging

if platform.platform().startswith('Windows'): #确认我们正在使用的操作系统
    #找出主驱动器，主文件夹，以及我们希望存储的文件名
    logging_file = os.path.join(os.getenv('HOMEDRIVE'),
                                os.getenv('HOMEPATH'),
                                'test.log' )
else:
    logging_file = os.path.join(os.getenv('HOME'),
                                'test.log')

print("Logging to",logging_file)
#配置logging模块，以特定的格式将所有信息写入我们指定的文件
logging.basicConfig(
    level=logging.DEBUG,
    format='%(asctime)s : %(levelname)s : %(message)s',
    filename=logging_file,
    filemode='w',
)
logging.debug("Start of the program")
logging.info("Doing something")
logging.warning("Dying now")
