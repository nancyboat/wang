
import requests
response = requests.get("https://foofish.net")
#状态码
print(response.status_code)
#原因短语
print(response.reason)
#响应首部
for name,value in response.headers.items():
    print("%s:%s"%(name,value))
print('--------------------------')
#响应内容
print(response.content)


