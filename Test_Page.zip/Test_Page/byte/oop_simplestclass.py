class Person:
    pass #一个空的代码块
p = Person()
print(p)