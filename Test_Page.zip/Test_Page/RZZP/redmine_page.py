
from redmin_locators import LoginPageLocators, MenuLocators
from time import sleep

class BasePage(object):
    def __init__(self, driver):
        self.driver = driver
    # def ele_locator(self, locator, timeout=10):
    #     """显性等待元素"""
    #     element = WebDriverWait(self.driver, timeout, 1).until(EC.presence_of_element_located(locator))
    #     print('a=',type(element))
    #     return element

class Login(BasePage):
    def user_login(self, username='wangls', password='wangls'):
        "获取用户登录信息,初始化登录帐号"
        self.driver.find_element(*LoginPageLocators.username).clear()
        self.driver.find_element(*LoginPageLocators.username).send_keys(username)
        self.driver.find_element(*LoginPageLocators.password).clear()
        self.driver.find_element(*LoginPageLocators.password).send_keys(password)
        self.driver.find_element(*LoginPageLocators.loginsubmit).click()
        return self.driver.title

class MenuPage(BasePage):
    def menu_butten(self):
        """定位简历下的所有菜单"""
        resume_menu = self.driver.find_element(*MenuLocators.resume_butten)
        menu_text = resume_menu.text
        if menu_text == '简历':
            # 点击一级菜单简历，加载二级菜单列表
            resume_menu = self.driver.find_element(*MenuLocators.resume_butten)
            resume_menu.click()
            print('简历菜单存在')
            sleep(3)
            # 查找二级菜单路径然后定义一个eles变量为list
            eles = self.driver.find_elements(*MenuLocators.second_menu)
            # 定义一个空列表，用来存储页面中存在的菜单文本
            lst1 = []
            # 循环读取找到的菜单元素
            for ele in eles:
                # 把元素的文本存到列表中
                lst1.append(ele.text)
            # 定义一个列表，用来存储预期的所有菜单文本
            lst2 = ["个人基础信息", "家庭状况", "教育经历", "培训经历", "工作经历", "相关信息", "原工作单位薪资情况", "附件管理"]
            #mark=1是成功找到菜单
            mark = 1
            for a in lst2:
                if a in lst1:
                    print("{} exist".format(a))
                else:
                    print("{} not exist ".format(a))
                    mark=0 #mark=0是未找到菜单
                    break
            return mark #返回mark值给单元测试判断
        else:
            print("简历菜单未找到")
            return 0




