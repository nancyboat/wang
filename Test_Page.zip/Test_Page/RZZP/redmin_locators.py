"""
将所有元素，按页面保存在不同的class下面
"""
from selenium.webdriver.common.by import By

class LoginPageLocators():
    """
    招聘系统登录界面使用的控件定位内容
    """
    username = (By.XPATH,"//input[starts-with(@id,'vp_hr_recruitment_web_login_JGTextBox1') and @class='form-control input-md']") #用户名
    password = (By.XPATH,"//input[starts-with(@id,'vp_hr_recruitment_web_login_JGPasswordBox1') and @type='password']") #密码
    loginsubmit = (By.XPATH,"//button[starts-with(@id,'vp_hr_recruitment_web_login_JGButton1') ]") #登录
    loginname = (By.XPATH,"//p[starts-with(@id,'vp_hr_recruitment_web_index_JGLabel4')] ") # 获取登录的标题

class MenuLocators():
    """
    招聘系统：二级菜单使用的控件定位内容
    """
    resume_butten = (By.XPATH,"//span[@class='title' and text()='简历']") #简历菜单
    second_menu = (By.XPATH,"//span[@class='content_ie8 title']")  #二级菜单


