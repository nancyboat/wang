from email.mime.text import MIMEText
from email.header import Header
from email.mime.multipart import MIMEMultipart

import smtplib
import os
# ==============定义发送邮件==========
def send_mail(file_new):
    """
  定义发送邮件内容
    """
    f = open(file_new, 'rb')
    mail_body = f.read()
    f.close()

    username = 'nancy870918@163.com'
    password = '1993wls'

    msg = MIMEMultipart('related')
    # 上传html附件
    att1 = MIMEText(mail_body, 'base64', 'utf-8')
    att1["Content-Type"] = 'application/octet-stream'
    att1["Content-Disposition"] = 'attachment;filename="result.html"'  # 这里的filename可以任意写，写什么名字，邮件中显示什么名字

    msg['Subject'] = Header("人资系统自动化测试报告", 'utf-8')
    msg['From'] = 'nancy870918@163.com'
    msg['To'] = 'wangls@toone.com.cn'
    msg.attach(att1)

    #发送邮件
    try:
        smtp = smtplib.SMTP()
        smtp.connect('smtp.163.com')
        smtp.login(username, password)
        smtp.sendmail('nancy870918@163.com', 'wangls@toone.com.cn', msg.as_string())
        smtp.quit()
        print("邮件已发出！注意查收。")
    except(Exception)as e:
        print("发送不成功！")
        print(e)

# ======查找测试目录，找到最新生成的测试报告文件======
def new_report(test_report):
    """
    查找测试目录，找到最新生成的测试报告文件
    """
    lists = os.listdir(test_report)  # 列出目录的下所有文件和文件夹保存到lists
    lists.sort(key=lambda fn: os.path.getmtime(test_report + "\\" + fn))  # 按时间排序
    file_new = os.path.join(test_report, lists[-1])  # 获取最新的文件保存到file_new
    print(file_new)
    return file_new

