from selenium import webdriver
import time
from time import sleep
import unittest
from redmine_page import Login, LeavePage
from HTMLTestRunner import HTMLTestRunner
from send_email import new_report, send_mail

class LoginTest(unittest.TestCase):
    @classmethod
    def setUpClass(self):
        self.driver = webdriver.Firefox()
        self.driver.maximize_window()
        self.driver.get('http://10.1.27.52:9011')
        self.driver.implicitly_wait(20)

    @classmethod
    def tearDownClass(self):
        self.driver.quit()

    # @unittest.skip("测试跳过")
    def test_01_login(self):
        loginpage = Login(self.driver)  # 实例化登录页面对象
        loginpage.user_login()
        ele = loginpage.get_login_name()
        self.assertIn('欢迎您', ele)

    def test_02_leave_application(self):
        leaveappliction = LeavePage(self.driver)
        leaveappliction.enter_leave_butten()
        sleep(1)
        leaveappliction.enter_leave_reason()
        sleep(1)
        leaveappliction.enter_leave_type()
        leaveappliction.enter_date_time()
        ele = leaveappliction.sucess_content
        self.assertIn('提交成功', ele)

    # def test_case3_leave_application(self):

if __name__ == '__main__':
    suite = unittest.TestSuite()
    suite.addTests(unittest.TestLoader().loadTestsFromTestCase(LoginTest))
    report_dir = 'D:\\py\\Test_Page\\RZ_Case\\report'
    # report_dir = './report'
    now = time.strftime("%Y-%m-%d %H-%M-%S")
    report_name = report_dir + '/' + now + 'result.html'
    with open(report_name, 'wb') as f:
        runner = HTMLTestRunner(stream=f, title="人资系统自动化", description="用例详情")
        runner.run(suite)
    latest_report = new_report(report_dir)
    send_mail(latest_report)
