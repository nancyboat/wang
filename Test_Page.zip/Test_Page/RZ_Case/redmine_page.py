
from redmin_locators import LoginPageLocators, LeaveAppLocators
from time import sleep
from datetime import datetime, timedelta
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC


class BasePage(object):
    def __init__(self, driver):
        self.driver = driver

    def find_elements(self, locator, timeout=10):
        """
        定位一组元素,参考locator为元祖类型
        """
        elements = WebDriverWait(self.driver, timeout, 1).until(EC.presence_of_all_elements_located(locator))
        return elements

class Login(BasePage):
    def user_login(self, username='liangmf', password=2):
        "获取用户登录信息,初始化登录帐号"
        self.driver.find_element(*LoginPageLocators.username).clear()
        self.driver.find_element(*LoginPageLocators.username).send_keys(username)
        self.driver.find_element(*LoginPageLocators.password).clear()
        self.driver.find_element(*LoginPageLocators.password).send_keys(password)
        self.driver.find_element(*LoginPageLocators.loginsubmit).click()

    def get_login_name(self):
        '''获取登录成功后的信息'''
        ele = self.driver.find_element(*LoginPageLocators.loginname)
        return ele.text

class LeavePage(BasePage):
    def enter_leave_butten(self):
        "定位请假申请按钮"
        try:
            leave_ele = self.driver.find_element(*LeaveAppLocators.leave_butten)
            leave_ele.click()
        except Exception as e:
            print('enter_leave_butten not found')

    def enter_leave_type(self):
        "输入请假类型"
        try:
            leave_ele = self.driver.find_element(*LeaveAppLocators.leave_type)
            leave_ele.click()
        except Exception as e:
            print(e)
            return u'请假类型未找到'

    def enter_leave_reason(self):
        "输入请假原因"
        return self.driver.find_element(*LeaveAppLocators.leave_reason).send_keys('测试请假')

    def enter_date_time(self):
        my_date = datetime.strftime(datetime.now(), '%Y-%m-%d')
        x = 0
        while my_date:

            # 赋值当前时间给开始时间和结束时间
            self.driver.find_element(*LeaveAppLocators.startdate).clear()
            sleep(1)
            self.driver.find_element(*LeaveAppLocators.enddate).clear()
            sleep(1)
            self.driver.find_element(*LeaveAppLocators.startdate).send_keys(my_date)
            sleep(1)
            self.driver.find_element(*LeaveAppLocators.enddate).send_keys(my_date)
            sleep(1)
            self.driver.find_element(*LeaveAppLocators.LeaveSubmit).click()
            sleep(4)
            self.content = self.driver.find_element(*LeaveAppLocators.LeaveSubmitContent).text
            sleep(4)
            if self.content == '提交成功':
                self.sucess_content = self.content
                break
            else:
                x = x + 1
                my_date = (datetime.now() + timedelta(days=x)).strftime("%Y-%m-%d")
