"""
将所有元素，按页面保存在不同的class下面
"""
from selenium.webdriver.common.by import By

class LoginPageLocators():
    """
    人资系统登录界面使用的控件定位内容
    """
    username = (By.XPATH,"//input[@widgetcode='JGTextBox1']") #用户名
    password = (By.XPATH,"//input[@widgetcode='JGPasswordBox1']") #密码
    loginsubmit = (By.XPATH,"//*[@widgetcode='JGButton1']") #登录
    loginname = (By.XPATH,"//span[contains(text(),'登录时间')] ") #登录后的内容显示

class LeaveAppLocators():
    """
    人资系统：请假申请界面使用的控件定位内容
    """
    leave_butten = (By.XPATH,"//img[starts-with(@id,'vp_hr_portal_myApply_web_JGImage1') and @class='img-responsive default pull-left']") #请假申请按钮
    # Leave_Context = (By.XPATH,"//h4[@id='myModalLabel' and @class='modal-title']")#判读获取的请假申请按钮内容
    leave_type = (By.XPATH,"//*[contains(text(),'事假')]")  #必填项申请假别选择事假
    leave_reason = (By.XPATH,"//*[@class='JGFormTextError'and @name='Cause']") #必填项请假原因
    startdate = (By.XPATH,"//input[starts-with(@id,'isc') and @name='startDate']") #开始时间
    enddate = (By.XPATH,"//input[starts-with(@id,'isc')and @name='endDate']")#结束时间
    LeaveSubmit = (By.XPATH,"//*[contains(text(),'提交')]")#请假提交按钮
    LeaveSubmitContent = (By.XPATH,"//div[@id='dialog_content_div'and @class='content']")#请假申请提交提示框内容

class OtAppLocators():
    """
    人资系统：加班申请界面使用的控件定位内容
    """
    ot_butten = (By.XPATH,"//img[starts-with(@id,'vp_hr_portal_myApply_web_JGImage2')]")#加班申请按钮
    ot_type = (By.XPATH,"//*[contains(text(),'公司内办公')]")#加班类型
    ot_reson = (By.XPATH,"//textarea[@name='overtimeReasons'and @class='JGFormTextError']")#加班原因
    ot_startdate =(By.XPATH,"//*[@name='startDate'and @class='JGFormIconTextError']")#加班开始时间
    ot_enddate = (By.XPATH,"//*[@name='endDate'and @class='JGFormIconTextError']")#加班结束时间
    ot_submit = (By.XPATH,"//*[contains(text(),'提交')]")#加班提交按钮
    ot_submit_content = (By.XPATH,"//*[@id='dialog_content_div'and @class='content']")#加班申请提交提示框内容

class BusinessLocators():
    """
    人资系统：出差申请界面使用的控件定位内容
    """
