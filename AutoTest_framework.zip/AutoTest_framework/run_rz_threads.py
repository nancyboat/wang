import sys
sys.path.append('C:\\Program Files (x86)\\Jenkins\workspace\\人资招聘系统脚本\\AutoTest_framework\\utils')
import unittest
from utils.config import CASE_PATH,REPORT_PATH
from BeautifulReport import BeautifulReport
from tomorrow import threads

casepath = CASE_PATH + '\\pro1_rz'
report = REPORT_PATH + '\\pro1_rz_report'

def add_case(casedir=casepath,rule="test*.py"):
    '''
    根据指定目录获取匹配的测试用例
    :param casedir:测试用例目录路径
    :param pattern:匹配模式
    :return:测试用例集
    '''
    discover_cases = unittest.defaultTestLoader.discover(casedir,pattern=rule)
    return discover_cases

#多线程下跑用到beautifulreport来合并测试报告
@threads(4)
def run(test_suit):
    result = BeautifulReport(test_suit)
    result.report(filename='report_threads.html',description='测试deafult报告', log_path=report)

if __name__ == '__main__':
    cases = add_case()#用例集合
    print(cases)
    for i in cases:
        print(i)
        run(i)
