from utils.config import Config
import pymssql
from utils.log import Logger

db = Config().get('DATABASES')
server = db.get('host')
user = db.get('username')
password = db.get('password')
database = db.get('database')

conn = pymssql.connect(server,user,password,database)
cur = conn.cursor()
sql = "select * from yzzx_client_baseInfo"
cur.execute(sql)
rows = cur.fetchall()
conn.close()
for row in rows:
    print(row[2])
