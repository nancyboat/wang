from test.common.browser import Browser
from selenium.webdriver.support.wait import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from utils.log import logger

class Page(Browser):
    def __init__(self,page=None,browser_type='Chrome'):
        if page:
            self.driver = page.driver
        else:
            super(Page,self).__init__(browser_type=browser_type)

    def get_driver(self):
        return self.driver

    def find_element(self, *args):
        return self.driver.find_element(*args)

        # try:
        #     #WebDriverWait(self.driver,1).until(EC.presence_of_element_located(args))
        #
        #     return self.driver.find_element(*args)
        # except:
        #     print('%s 页面未找到元素 %s'%(self,args))



    def find_elements(self, *args):
        return self.driver.find_elements(*args)
