from test.common.browser import Browser
from selenium.webdriver.support.wait import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from utils.log import logger

class Page(Browser):
    def __init__(self,page=None,browser_type='Chrome'):
        if page:
            self.driver = page.driver
        else:
            super(Page,self).__init__(browser_type=browser_type)

    def get_driver(self):
        return self.driver

    def find_element(self, *args):

        ele = WebDriverWait(self.driver, 10).until(EC.presence_of_element_located(args))
        return ele



    def find_elements(self, *args):
        return self.driver.find_elements(*args)
