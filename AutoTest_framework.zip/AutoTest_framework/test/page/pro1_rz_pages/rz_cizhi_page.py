from selenium.webdriver.common.by import By
from selenium.common.exceptions import NoSuchElementException
from test.common.page import Page
from time import sleep
from utils.config import Config
from datetime import datetime, timedelta
from utils.log import logger
from test.page.pro1_rz_pages.rz_login_page import RZLoginPage

class CizhiAppLocators(Page):
    """
            人资系统：辞职界面使用的控件定位内容
    """

    cizhi_button = (By.XPATH,"//img[starts-with(@id,'vp_hr_portal_myApply_web_JGImage4')]")#辞职申请按钮
    chizhi_xzbutton = (By.XPATH,"//span[@eventpart='valueicon']") #离职须知勾选
    cizhi_reason = (By.XPATH,"//input[starts-with(@value,'找到更好的工作机会')]")#定位辞职原因
    cizhi_explain = (By.XPATH,"//textarea[starts-with(@name,'leaveReasonDes')]")#定位辞职说明
    cizhi_achievement = (By.XPATH,"//textarea[starts-with(@name,'outstanding')]")#定位任职业绩
    cizhi_plan = (By.XPATH,"//textarea[starts-with(@name,'futurePlanning')]")#定位今后的职业规划
    cizhi_suggestion = (By.XPATH,"//textarea[starts-with(@name,'otherSuggestions')]")#定位建议
    cizhi_things = (By.XPATH,"//*[contains(text(),'新增')]")#新增按钮
    cizhi_name1 = (By.XPATH, "//table[@class='listTable'and@width='779']//tbody/tr[1]/td[2]")  # 点击交接事项定位
    cizhi_name = (By.XPATH,"//table[@class='listTable'and@width='779']//tbody/tr[1]/td[2]//nobr/span/input")#交接事项名称传值
    cizhi_neirong1 = (By.XPATH,"//table[@class='listTable'and@width='779']//tbody/tr[1]/td[3]")  #点击交接内容定位
    cizhi_neirong = (By.XPATH,"//table[@class='listTable'and@width='779']//tbody/tr[1]/td[3]//nobr/span/input")#交接事项内容传值
    cizhi_submit = (By.XPATH,"//*[contains(text(),'暂存')]")  # 定位单据暂存按钮，因为单据提交后就无法重现提交
    cizhi_submit_content = (By.XPATH, "//div[@id='dialog_content_div'and @class='content']")


    def enter_cizhi_button(self):
        try:
            self.find_element(*self.cizhi_button).click()
        except NoSuchElementException as e:
            print("辞职按钮未找到，原因%s"%e)

    def enter_chizhi_xzbutton(self):
        try:
            self.find_element(*self.chizhi_xzbutton).click()
        except NoSuchElementException as e:
            print("离职须知勾选未找到，原因%s"%e)

    def enter_cizhi_reason(self):
        try:
            self.find_element(*self.cizhi_reason).click()
        except NoSuchElementException as e:
            print("辞职原因按钮未找到，原因%s"%e)

    def enter_cizhi_explain(self):
        try:
            self.find_element(*self.cizhi_explain).send_keys(u'辞职说明')
        except NoSuchElementException as e:
            print("辞职说明未找到，原因%s" % e)

    def enter_cizhi_achievement(self):
        try:
            self.find_element(*self.cizhi_achievement).send_keys(u'任职业绩')
        except NoSuchElementException as e:
            print("任职业绩未找到，原因%s" % e)

    def enter_cizhi_plan(self):
        try:
            self.find_element(*self.cizhi_plan).send_keys(u'职业规划')
        except NoSuchElementException as e:
            print("职业规划未找到，原因%s" % e)

    def enter_cizhi_suggestion(self):
        try:
            self.find_element(*self.cizhi_suggestion).send_keys(u'建议')
        except NoSuchElementException as e:
            print("建议未找到，原因%s" % e)

    def enter_cizhi_things(self):
        try:
            self.find_element(*self.cizhi_things).click()
        except NoSuchElementException as e:
            print("新增按钮未找到，原因%s" % e)

    def enter_jiaojie(self):
        try:
            self.find_element(*self.cizhi_name1).click()
            self.find_element(*self.cizhi_name1).click()
            self.find_element(*self.cizhi_name).send_keys(u'事项1')
            sleep(1)
            self.find_element(*self.cizhi_neirong1).click()
            self.find_element(*self.cizhi_neirong1).click()
            self.find_element(*self.cizhi_neirong).send_keys(u'内容1')
        except NoSuchElementException as e:
            print("交接失败，原因%s" % e)

    def enter_cizhi_submit(self):
        try:
            self.find_element(*self.cizhi_submit).click()
        except NoSuchElementException as e:
            print("提交按钮未找到，原因%s" % e)

    def enter_dd_submit_content(self):
        content = self.find_element(*self.cizhi_submit_content).text
        return content

if __name__ == '__main__':
    URL = Config().get('URL_RZ')
    page = RZLoginPage(browser_type='Firefox').get(URL, maximize_window=True, implicitly_wait=20)
    page.tenantuserlogin()
    sleep(4)
    page.userlogin()
    result = CizhiAppLocators(page)
    result.enter_cizhi_button()
    sleep(5)
    result.enter_chizhi_xzbutton()
    sleep(2)
    result.enter_cizhi_reason()
    sleep(3)
    result.enter_cizhi_explain()
    sleep(3)
    result.enter_cizhi_achievement()
    sleep(3)
    result.enter_cizhi_plan()
    sleep(3)
    result.enter_cizhi_suggestion()
    sleep(3)
    result.enter_cizhi_things()
    sleep(3)
    result.enter_jiaojie()
    sleep(3)
    result.enter_cizhi_submit()

