import time
from selenium import webdriver
from selenium.webdriver.common.by import By


driver = webdriver.Chrome()
driver.implicitly_wait(10)
driver.get('http://wxdev2.vtoone.com/test_hr/module-operation!executeOperation?componentCode=vp_hr_login&windowCode=loginVBASE')

driver.find_element(By.XPATH,"//input[@widgetcode='JGTextBox1']").send_keys('wangt')
time.sleep(1)
driver.find_element(By.XPATH,"//input[@widgetcode='JGPasswordBox1']").send_keys('8')
driver.find_element(By.XPATH,"//*[@widgetcode='JGButton1']").click()
driver.find_element(By.XPATH,"//img[starts-with(@id,'vp_hr_portal_myApply_web_JGImage4')]").click()
time.sleep(1)
# driver.find_element(By.XPATH,"//div[starts-with(@id,'isc') and contains(text(),'调入部门')]").click()
driver.find_element(By.XPATH,"//*[contains(text(),'新增')]").click()
time.sleep(1)
driver.find_element_by_xpath("//table[@width='778']//tbody/tr[1]/td[2]").click()
driver.find_element_by_xpath("//table[@width='778']//tbody/tr[1]/td[2]").click()
driver.find_element_by_xpath("//table[@width='778']//tbody/tr[1]/td[2]/div/nobr/span/input").send_keys("项目")

driver.find_element_by_xpath("//table[@width='778']//tbody/tr[1]/td[3]").click()
driver.find_element_by_xpath("//table[@width='778']//tbody/tr[1]/td[3]").click()
driver.find_element_by_xpath("//table[@width='778']//tbody/tr[1]/td[3]/div/nobr/span/input").send_keys("交接内容")

# dd_bumen = (By.XPATH,"//div[starts-with(@id,'isc') and @class='JGTextBox38a819bb465219a26016521a0bba1621aTitleReadOnly']") #调入部门
# time.sleep(2)
# js = 'var arr=document.getElementsByName("tarOrgName")[0].removeAttribute("readonly");'
# driver.execute_script(js)
#
# js_value = 'var arr=document.getElementsByName("tarOrgName")[0].value="信息管理部"'
# driver.execute_script(js_value)
# time.sleep(2)
# js = 'var arr=document.getElementsByName("tarTitleName")[0].removeAttribute("readonly");'
# driver.execute_script(js)
#
# js_value = 'var arr=document.getElementsByName("tarTitleName")[0].value="测试工程师"'
# driver.execute_script(js_value)
#
# driver.find_element(By.XPATH,"//*[starts-with(@id,'isc') and @name='moveReason']").send_keys('调动原因')
# driver.find_element(By.XPATH,"//*[contains(text(),'新增')]").click()
# time.sleep(1)
# dd_name1 = (By.XPATH, "//table[starts-with(@id,'isc') and @class='listTable']/tbody/tr/td[2]")  # 双击的事项输入框定位
# dd_name = (By.XPATH, "//input[starts-with(@id,'isc') and @name='contentName']")  # 交接事项名称
# driver.find_element(dd_name1).click()
# driver.find_element(dd_name1).click()
# driver.find_element(dd_name).send_keys(u'事项1')
