from selenium.webdriver.common.by import By
from test.common.page import Page
from time import sleep
from utils.config import Config
from datetime import datetime, timedelta
from utils.log import logger
from test.page.pro1_rz_pages.rz_login_page import RZLoginPage

class WaichuAppLocators(Page):
    """
    外出系统，外出申请界面使用的空间内容
    """

    waichu_button = (By.XPATH,"// img[starts-with(@id,'vp_hr_portal_myApply_web_JGImage6')]") #外出申请按钮
    waichu_reason = (By.XPATH,"//*[@class='JGFormTextError'and @name='outReasons']") #外出原因
    waichu_startdate = (By.XPATH,"//input[starts-with(@id,'isc') and @name='startDate']")#外出开始时间
    waichu_enddate = (By.XPATH,"//input[starts-with(@id,'isc')and @name='endDate']") #外出结束时间
    waichu_submit = (By.XPATH, "//*[contains(text(),'提交')]")  # 外出提交按钮
    waichu_submit_content = (By.XPATH, "//*[@id='dialog_content_div'and @class='content']")  # 外出申请提交提示框内容
    waichu_startdate1 = (By.XPATH,"//input[starts-with(@id,'isc') and @name='startDate']")
    waichu_enddate1 = (By.XPATH,"//input[starts-with(@id,'isc')and @name='endDate']")

    def enter_waichu_button(self):
        try:
            self.find_element(*self.waichu_button).click()
        except Exception as e:
            print("外出申请按钮未找到，原因%s"%e)

    def enter_waichu_reason(self):
        return self.find_element(*self.waichu_reason).send_keys(u'测试外出申请')

    def enter_date_time(self):
        my_date = datetime.strftime(datetime.now(), '%Y-%m-%d')
        x = 0
        while my_date:
        # 赋值当前时间给开始时间和结束时间
            self.find_element(*self.waichu_startdate).clear()
            sleep(1)
            self.find_element(*self.waichu_enddate).clear()
            sleep(1)
            self.find_element(*self.waichu_startdate).send_keys(my_date)
            sleep(3)
            self.find_element(*self.waichu_enddate).send_keys(my_date)
            sleep(3)
            self.find_element(*self.waichu_submit).click()
            sleep(3)
            self.content = self.driver.find_element(*self.waichu_submit_content).text
            print(self.content)
            sleep(5)
            if self.content == '提交成功':
                self.success_content = self.content
                break
            else:
                self.find_element(*self.waichu_startdate1).clear()
                self.find_element(*self.waichu_enddate1).clear()
                x = x+1
                my_date = (datetime.now() + timedelta(days=x)).strftime("%Y-%m-%d")

if __name__ == '__main__':
    URL = Config().get('URL')
    page = RZLoginPage(browser_type='Chrome').get(URL, maximize_window=False)
    page.userlogin()
    result = WaichuAppLocators(page)
    result.enter_waichu_button()
    sleep(1)
    result.enter_waichu_reason()
    sleep(1)
    result.enter_date_time()

