from selenium.webdriver.common.by import By

from test.common.page import Page


class OutsideAppLocators(Page):
    """
    人资系统：外出申请界面使用的控件定位内容
    """
    outside_button = (By.XPATH,"//img[starts-with(@id,'vp_hr_portal_myApply_web_JGImage6)']")