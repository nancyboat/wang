from selenium.webdriver.common.by import By
from test.common.page import Page
from time import sleep
from utils.config import Config
from datetime import datetime, timedelta
from utils.log import logger
from test.page.pro1_rz_pages.rz_login_page import RZLoginPage

class DdAppLocators(Page):
    """
        人资系统：调动申请界面使用的控件定位内容
        """
    dd_button = (By.XPATH,"//img[starts-with(@id,'vp_hr_portal_myApply_web_JGImage5')]") #调动申请按钮
    dd_bumen = (By.XPATH,"//div[starts-with(@id,'isc') and contains(text(),'调入部门')]") #调入部门
    dd_bumen_1 = (By.XPATH,"//*[contains(text(),'企业管理部')]")  #定位部门
    dd_bumen_2 = (By.XPATH,"//*[contains(text(),'确认')]") #提交部门
    dd_zhiwei = (By.XPATH,"//div[starts-with(@id,'isc') and contains(text(),'调入职位')]") #调入职位
    dd_zhiwei1 = (By.XPATH,"//*[contains(text(),'副总裁')]")#定位职位
    dd_zhiwei2 = (By.XPATH,"//*[contains(text(),'确定')]")#提交职位
    dd_reasons = (By.XPATH,"//*[starts-with(@id,'isc') and @name='moveReason']") #调动原因
    dd_things = (By.XPATH,"//*[contains(text(),'新增')]") #子表交接新增按钮
    dd_name1 = (By.XPATH,"//table[@width='610']//tbody/tr[1]/td[2]")#点击交接事项
    dd_name = (By.XPATH,"//table[@width='610']//tbody/tr[1]/td[2]/div/nobr/span/input") #交接事项名称传值
    dd_neirong1 = (By.XPATH,"//table[@width='610']//tbody/tr[1]/td[3]")#点击交接内容
    dd_neirong = (By.XPATH,"//table[@width='610']//tbody/tr[1]/td[3]/div/nobr/span/input")#交接事项内容传值
    dd_submit = (By.XPATH,"//*[contains(text(),'暂存')]")#定位单据暂存按钮，因为单据提交后就无法重现提交
    dd_submit_content = (By.XPATH,"//div[@id='dialog_content_div'and @class='content']")


    def enter_dd_button(self):
        try:
            self.find_element(*self.dd_button).click()
        except Exception as e:
            print("调动按钮未找到，原因%s"%e)

    def enter_dd_bumen(self):
        try:
            self.find_element(*self.dd_bumen).click()
        except Exception as e:
            print("调入部门未找到，原因%s"%e)

    def enter_choose_bumen(self):
        try:
            self.find_element(*self.dd_bumen_1).click()
            sleep(2)
            self.find_element(*self.dd_bumen_2).click()
        except Exception as e:
            print("部门未找到，原因%s"%e)

    def enter_dd_zhiwei(self):
        try:
            self.find_element(*self.dd_zhiwei).click()
        except Exception as e:
            print("调入职位未找到，原因%s" % e)

    def enter_choose_zhiwei(self):
        try:
            self.find_element(*self.dd_zhiwei1).click()
            sleep(1)
            self.find_element(*self.dd_zhiwei2).click()
        except Exception as e:
            print("职位未找到，原因%s" % e)

    def enter_dd_reasons(self):
        try:
            self.find_element(*self.dd_reasons).send_keys(u'测试调动申请')
        except Exception as e:
            print("调动原因未找到，原因%s" % e)

    def enter_dd_things(self):
        try:
            self.find_element(*self.dd_things).click()
        except Exception as e:
            print("新增按钮未找到，原因%s" % e)

    def enter_jiaojie(self):
        # try:
        self.find_element(*self.dd_name1).click()
        self.find_element(*self.dd_name1).click()
        self.find_element(*self.dd_name).send_keys(u'事项1')
        sleep(1)
        self.find_element(*self.dd_neirong1).click()
        self.find_element(*self.dd_neirong1).click()
        self.find_element(*self.dd_neirong).send_keys(u'内容1')
        # except Exception as e:
        #     print("交接失败，原因%s" % e)

    def enter_dd_submit(self):
        try:
            self.find_element(*self.dd_submit).click()
        except Exception as e:
            print("提交按钮未找到，原因%s" % e)

    def enter_dd_submit_content(self):
        content=self.find_element(*self.dd_submit_content).text
        return content

if __name__ == '__main__':
    URL = Config().get('URL')
    page = RZLoginPage(browser_type='Chrome').get(URL, maximize_window=False, implicitly_wait=20)
    page.userlogin()
    result = DdAppLocators(page)
    result.enter_dd_button()
    sleep(3)
    result.enter_dd_bumen()
    sleep(3)
    result.enter_choose_bumen()
    sleep(3)
    result.enter_dd_zhiwei()
    sleep(3)
    result.enter_choose_zhiwei()
    sleep(3)
    result.enter_dd_reasons()
    sleep(3)
    result.enter_dd_things()
    sleep(3)
    result.enter_jiaojie()
    sleep(4)
    result.enter_dd_submit()
