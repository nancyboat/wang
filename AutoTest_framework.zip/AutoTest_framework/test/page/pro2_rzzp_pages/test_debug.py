from selenium import webdriver
from selenium.webdriver.support.wait import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from selenium.webdriver.common.by import By
from time import sleep

username =(By.XPATH,"//input[starts-with(@id,'vp_hr_recruitment_web_login_JGTextBox1') and @class='form-control input-md']")
password = (By.XPATH, "//input[starts-with(@id,'vp_hr_recruitment_web_login_JGPasswordBox1') and @type='password']")
loginsubmit = (By.XPATH, "//button[starts-with(@id,'vp_hr_recruitment_web_login_JGButton1') ]")
loginname = (By.XPATH, "//p[starts-with(@id,'vp_hr_recruitment_web_index_JGLabel4')] ")

def find_element( *args):

    ele = WebDriverWait(driver,10,0.5).until(EC.presence_of_element_located(args))
    #ele = WebDriverWait(driver, 10,0.5).until(lambda x:x.find_element(*args))
    return ele

def userlogin(userneme = 'wangls',password = 'wangls'):
    #print(type(password))

    #find_element(*username).send_keys(userneme)
    find_element(*password)
    print(*password)
    # find_element(*loginsubmit).click()


def get_login_name(self):

    login_text = self.find_element(*self.loginname)
    return login_text.text

if __name__=="__main__":
    driver = webdriver.Firefox()
    driver.get('http://10.1.28.52:9011/module-operation!executeOperation?operation=Form&componentCode=vp_hr_recruitment_web&windowCode=login')
    userlogin()
