from selenium.webdriver.common.by import By
from test.common.page import Page
from time import sleep
from utils.config import Config

class RZZPLoginPage(Page):
    """
    招聘系统登录界面使用的控件定位内容
    """
    username = (By.XPATH,"//input[starts-with(@id,'vp_hr_recruitment_web_login_JGTextBox1') and @class='form-control input-md']")  # 用户名
    password = (By.XPATH, "//input[starts-with(@id,'vp_hr_recruitment_web_login_JGPasswordBox1') and @type='password']")  # 密码
    loginsubmit = (By.XPATH, "//button[starts-with(@id,'vp_hr_recruitment_web_login_JGButton1') ]")  # 登录
    loginname = (By.XPATH, "//p[starts-with(@id,'vp_hr_recruitment_web_index_JGLabel4')] ")  # 获取登录的标题

    def userlogin(self,userneme = 'wangls',password = 'wangls'):
        '''

        :param userneme: 招聘系统登录用户名，默认一个登录用户
        :param password:
        :return:
        '''
        self.find_element(*self.username).send_keys(userneme)
        self.find_element(*self.password).send_keys(password)
        self.find_element(*self.loginsubmit).click()
        sleep(1)

    def get_login_name(self):

        return self.find_element(*self.loginname).text


class MenuLocators(Page):
    """
    招聘系统：二级菜单使用的控件定位内容
    """
    resume_butten = (By.XPATH,"//span[@class='title' and text()='简历']") #简历菜单
    second_menu = (By.XPATH,"//span[@class='content_ie8 title']")  #二级菜单

    def menu_butten(self):
        '''定位简历下的所有菜单'''
        resume_menu = self.find_element(*self.resume_butten).text
        if resume_menu == '简历': #点击一级菜单简历，加载二级菜单列表
            self.find_element(*self.resume_butten).click()
            print("简历菜单已存在")
            sleep(3)
            ## 查找二级菜单路径然后定义一个eles变量为list
            eles = self.find_elements(*self.second_menu)
            # 定义一个空列表，用来存储页面中存在的菜单文本
            lst1 = []
            # 循环读取找到的菜单元素
            for ele in eles:
                lst1.append(ele.text) # 把元素的文本存到列表中
            #print(lst1)
            # 定义一个列表，用来存储预期的所有菜单文本
            lst2 = ["个人基础信息", "家庭状况", "教育经历", "培训经历", "工作经历", "相关信息", "原工作单位薪资情况", "附件管理"]
            # mark=1是成功找到菜单
            mark = 1
            for a in lst2:
                if a in lst1:
                    print("{}存在".format(a))
                else:
                    print("{}不存在".format(a))
                    mark = 0  # mark=0是未找到菜单
                    break
            return mark
        else:
            print("简历菜单未找到")


if __name__ == '__main__':
    URL = Config().get('URL_RZZP')
    page = RZZPLoginPage(browser_type='Chrome').get(URL,maximize_window=False)
    page.userlogin()
    pageresult = MenuLocators(page)
    pageresult.menu_butten()
    page.quit()