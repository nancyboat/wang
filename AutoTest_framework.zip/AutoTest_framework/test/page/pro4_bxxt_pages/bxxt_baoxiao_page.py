from datetime import datetime
from time import sleep
from selenium.webdriver.common.by import By
from test.common.page import Page
from test.page.pro4_bxxt_pages.bxxt_login_page import BXLoginPage
from utils.config import Config



class BaoXiaoAppLocators(Page):
    """
    报销系统：财务报销界面使用的控件定位内容
    """
    baoxiao_button = (By.XPATH, "//*[starts-with(@id,'erp_loginframe_index_link_bizMrg') and @class='v-label v-font-size-h5']")  #财务报销按钮
    chailv_button = (By.XPATH,"//nobr[contains(text(),'差旅报销')]")  #差旅报销按钮
    leave_reason = (By.XPATH, "//input[starts-with(@id,'isc') and @name='reason']")  # 必填项出差事由
    happen_date = (By.XPATH,"//table[@width='764']//tbody/tr[1]/td[2]")
    happendate = (By.XPATH, "//*[starts-with(@id,'isc') and @name='happendate']")  #必填项日期
    start_Place = (By.XPATH,"//table[@width='764']//tbody/tr[1]/td[3]")
    startPlace = (By.XPATH, "//*[starts-with(@id,'isc') and @name='startPlace']")  #必填项出发地
    arrive_Place = (By.XPATH,"//table[@width='764']//tbody/tr[1]/td[4]")
    arrivePlace = (By.XPATH, "//*[starts-with(@id,'isc') and @name='arrivePlace']")  #必填项到达地
    travel_Expense = (By.XPATH,"//table[@width='764']//tbody/tr[1]/td[5]")
    travelExpense = (By.XPATH, "//*[starts-with(@id,'isc') and @name='travelExpense']")  #车船费
    hotel_Expense = (By.XPATH,"//table[@width='764']//tbody/tr[1]/td[6]")
    hotelExpense = (By.XPATH, "//*[starts-with(@id,'isc') and @name='hotelExpense']")  #住宿费
    other_Expense = (By.XPATH,"//table[@width='764']//tbody/tr[1]/td[7]")
    otherExpense = (By.XPATH, "//*[starts-with(@id,'isc') and @name='otherExpense']")  #其他费用
    count = (By.XPATH,"//*[starts-with(@id,'isc')and @name='reimburseAmount']")  #报销金额合计
    shouldSubsidy = (By.XPATH,"//*[starts-with(@id,'isc')and @name='shouldSubsidy']")  #应计补助
    costExplain = (By.XPATH,"//*[starts-with(@id,'isc') and @name='costExplain']")  #必填项出差总结及费用说明
    save_button = (By.XPATH,"//nobr[contains(text(),'保存')]")  #保存按钮
    submit_button = (By.XPATH,"//*[contains(text(),'提交')]")  #提交按钮
    dialog_Confirm = (By.XPATH,"//*[@id='dialogConfirm']")  #确定按钮
    confirm_submit = (By.XPATH,"//*[@id='dialog_content_div'and @class='content']")  #差旅报销提交提示框内容



    def enter_baoxiao_button(self):
        """定位财务报销按钮"""
        try:
            self.find_element(*self.baoxiao_button).click()
        except Exception as e:
            print('财务报销按钮未找到，原因%s'%e)

    def enter_chailv_button(self):
        """定位差旅报销按钮"""
        try:
            self.find_element(*self.chailv_button).click()
        except Exception as e:
            print('差旅报销按钮未找到，原因%s'%e)

    def enter_leave_reason(self):
        """"输入出差事由"""
        return self.find_element(*self.leave_reason).send_keys(u'测试差旅报销')

    def enter_happen_date(self):
        """输入差旅发生日期"""
        try:
            self.find_element(*self.happen_date).click()
            self.find_element(*self.happen_date).click()
            my_date = datetime.strftime(datetime.now(), '%Y-%m-%d')
            self.find_element(*self.happendate).send_keys(my_date)
        except Exception as e:
            print('差旅发生日期填写失败，原因%s'%e)

    def enter_start_Place(self):
        """输入出发地"""
        try:
            self.find_element(*self.start_Place).click()
            self.find_element(*self.start_Place).click()
            self.find_element(*self.startPlace).send_keys(u'珠海')
        except Exception as e:
            print('出发地填写失败，原因%s'%e)

    def enter_arrive_Place(self):
        """输入到达地"""
        try:
            self.find_element(*self.arrive_Place).click()
            self.find_element(*self.arrive_Place).click()
            self.find_element(*self.arrivePlace).send_keys(u'广州')
        except Exception as e:
            print('到达地填写失败，原因%s'%e)

    def enter_travel_Expense(self):
        """输入车船费"""
        try:
            self.find_element(*self.travel_Expense).click()
            self.find_element(*self.travel_Expense).click()
            self.find_element(*self.travelExpense).send_keys(u'350')
        except Exception as e:
            print('车船费填写失败，原因%s'%e)

    def enter_hotel_Expense(self):
        """输入住宿费"""
        try:
            self.find_element(*self.hotel_Expense).click()
            self.find_element(*self.hotel_Expense).click()
            self.find_element(*self.hotelExpense).send_keys(u'180')
        except Exception as e:
            print('住宿费填写失败，原因%s'%e)

    def enter_other_Expense(self):
        """输入其他费用"""
        try:
            self.find_element(*self.other_Expense).click()
            self.find_element(*self.other_Expense).click()
            self.find_element(*self.otherExpense).send_keys(u'80')
        except Exception as e:
            print('其他费用填写失败，原因%s'%e)

    def enter_costExplain(self):
        """输入出差总结及费用说明"""
        try:
            self.find_element(*self.costExplain).click()
            self.find_element(*self.costExplain).send_keys(u'这是出差总结及相关费用说明')
        except Exception as e:
            print('出差总结及费用说明填写失败，原因%s'%e)

    def get_count(self):
        """获取报销金额合计数"""
        try:
            self.find_element(*self.count).click()
            count = self.find_element(*self.count).get_attribute('value')
            print(count)
            return  count
        except Exception as e:
            print('获取报销金额合计数失败，原因%s'%e)

    def enter_Submit(self):
        """点击提交"""
        try:
            self.find_element(*self.save_button).click()
            sleep(8)
            self.find_element(*self.submit_button).click()
            sleep(4)
            self.find_element(*self.dialog_Confirm).click()
            sleep(3)
            content = self.driver.find_element(*self.confirm_submit).text
            print(content)
            #sleep(5)
            if content == '提交成功！':
                print('单据填报提交完成，用例成功')

        except Exception as e:
            print('提交失败，原因%s'%e)

    def print_result(self):
        "输出费用明细"
        try:
            chechuan = self.find_element(*self.travel_Expense).text  #获取车船费用
            zhusu = self.find_element(*self.hotel_Expense).text #获取住宿费用
            other = self.find_element(*self.other_Expense).text  #获取其他费用
            buzhu = self.find_element(*self.shouldSubsidy).get_attribute('value')
            print('车船费用:%s'%chechuan)
            print('住宿费用:%s'%zhusu)
            print('其他费用:%s'%other)
            print('补助费用:%s'%buzhu)

        except Exception as e:
            print('输出费用明细失败，原因%s'%e)



if __name__ == '__main__':
    URL = Config().get('URL_BX')
    page = BXLoginPage(browser_type='Chrome').get(URL, maximize_window=False)
    page.tenantuserlogin()
    sleep(1)
    page.userlogin()
    sleep(2)
    result = BaoXiaoAppLocators(page)
    sleep(2)
    result.enter_baoxiao_button()
    sleep(5)
    result.enter_chailv_button()
    sleep(8)
    result.enter_leave_reason()
    sleep(2)
    result.enter_happen_date()
    sleep(2)
    result.enter_start_Place()
    sleep(2)
    result.enter_arrive_Place()
    sleep(2)
    result.enter_travel_Expense()
    sleep(2)
    result.enter_hotel_Expense()
    sleep(2)
    result.enter_other_Expense()
    sleep(2)
    result.enter_costExplain()
    sleep(2)
    result.print_result()
    #result.get_count()
    #sleep(2)
    #result.enter_Submit()


