from selenium.webdriver.common.by import By
from test.common.page import Page
from time import sleep
from utils.config import Config
from datetime import datetime, timedelta
from utils.log import logger
from test.page.pro3_gw_pages.fw_login_page import GWLoginPage

class FawenApplocators(Page):
    """"""
    bangong_button = (By.XPATH,"//*[contains(text(),'智能办公')]")#定位“智能办公”按钮
    gwguanli_button = (By.XPATH,"//*[contains(text(),'公文管理')]")#定位“公文管理”菜单按钮
    xinzeng = (By.XPATH,"//*[contains(text(),'新增公文')]")#定位“新增公文”菜单按钮
    jtfawen = (By.XPATH,"//*[contains(text(),'发文流程')]")#定位“集团发文”按钮
    biaoti = (By.XPATH,"//textarea[starts-with(@id,'voa225pc_mobile_form_fwngHtm_form_DocTitle')]")#定位“标题”
    zhudw = (By.XPATH, "//textarea[starts-with(@id,'voa225pc_mobile_form_fwngHtm_form_SendToOrgName')]")  # 定位“主送单位”
    chaodw = (By.XPATH, "//textarea[starts-with(@id,'voa225pc_mobile_form_fwngHtm_form_CopySendToOrgName')]")  # 定位“抄送单位”

    # youyi_button = (By.XPATH,"//div[starts-with(@id,'isc') and eventproxy='isc_JGButton_12']")#定位右移按钮
    # queding_button = (By.XPATH, "//*[contains(text(),'确定')]")  # 定位确定按钮
    tijiao_button = (By.XPATH, "//*[contains(text(),'提交')]") # 定位提交按钮
    fwguanli_button = (By.XPATH, "//*[contains(text(),'发文管理')]")  # 定位“发文管理”菜单按钮
    lianjie = (By.XPATH,"//span[contains(@onclick,'isc_JGDataGrid_0.fireLink(0,1)')]")#定位标题链接//*[@id="isc_A1table"]/tbody/tr[1]/td[2]/div/nobr/span
    shenpi_button = (By.XPATH, "//nobr[contains(text(),'提交')]")  # 定位审批提交按钮//*[@id="isc_BL"]/nobr
    qdtijiao_button = (By.XPATH, "//input[contains(@value,'确定')]")  # 定位确定提交按钮
    dangan = (By.XPATH, "//*[contains(text(),'d')]") #定位档案
    xuanze = (By.XPATH, "//label[contains(text(),'选择')][last()]")  # 定位“选择”按钮


    def enter_bangong_button(self):
        """定位智能办公按钮"""

        self.find_element(*self.bangong_button).click()


    def enter_gwguanli_button(self):
        """定位公文管理按钮"""
        try:
            self.find_element(*self.gwguanli_button).click()
        except Exception as e:
            print('公文管理按钮未找到，原因%s' % e)

    def enter_xinzeng(self):
        """定位新增公文按钮"""
        try:
            self.find_element(*self.xinzeng).click()
        except Exception as e:
            print('新增公文按钮未找到，原因%s' % e)

    def enter_jtfawen(self):
        """定位集团发文按钮"""
        try:
            self.find_element(*self.jtfawen).click()
        except Exception as e:
            print('发文流程按钮未找到，原因%s' % e)

    def enter_biaoti(self):
        """输入标题"""
        try:
            self.find_element(*self.biaoti).send_keys('发文自动化测试')
        except Exception as e:
            print('标题未找到，原因%s' % e)

    def enter_zhudw(self):
        """输入主送单位"""
        try:
            self.find_element(*self.zhudw).send_keys('测试主送单位')
        except Exception as e:
            print('主送单位未找到，原因%s' % e)

    def enter_chaodw(self):
        """输入抄送单位"""
        try:
            self.find_element(*self.chaodw).send_keys('测试抄送单位')
        except Exception as e:
            print('抄送单位未找到，原因%s' % e)

    def enter_xuanze(self):
        """定位提交"""
        try:
            self.find_element("//label[contains(text(),'选择')")[-1].click()
        except Exception as e:
            print('选择按钮未找到，原因%s' % e)

    def enter_tijiao_button(self):
        """定位提交"""
        try:
            self.find_element(*self.tijiao_button).click()
        except Exception as e:
            print('提交按钮未找到，原因%s' % e)

    def enter_fwguanli_button(self):
        """定位发文管理"""
        try:
            self.find_element(*self.fwguanli_button).click()
        except Exception as e:
            print('发文管理未找到，原因%s' % e)

    def enter_lianjie(self):
        """定位标题链接"""
        try:
            self.find_element(*self.lianjie).click()
        except Exception as e:
            print('标题链接未找到，原因%s' % e)

    def enter_shenpi_button(self):
        """定位提交按钮"""
        try:
            self.find_element(*self.shenpi_button).click()
        except Exception as e:
            print('提交未找到，原因%s' % e)

    def enter_qdtijiao_button(self):
        """定位确认按钮"""
        try:
            self.find_element(*self.qdtijiao_button).click()
        except Exception as e:
            print('确认按钮未找到，原因%s' % e)

    def enter_dangan(self):
        """定位确认按钮"""
        try:
            self.find_element(*self.dangan).click()
        except Exception as e:
            print('档案按钮未找到，原因%s' % e)

if __name__ == '__main__':
    URL = Config().get('URL_GW')
    page = GWLoginPage(browser_type='Chrome').get(URL, maximize_window=True,implicitly_wait=30)
    page.userlogin()
    result = FawenApplocators(page)
    result.enter_bangong_button()

    result.enter_gwguanli_button()

    result.enter_xinzeng()

    result.enter_jtfawen()

    result.enter_biaoti()

    result.enter_zhudw()

    result.enter_chaodw()

    # result.enter_people()
    # sleep(1)
    result.enter_tijiao_button()

    result.enter_fwguanli_button()

    result.enter_lianjie()

    result.enter_shenpi_button()

    result.enter_qdtijiao_button()
