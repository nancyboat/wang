from selenium.webdriver.common.by import *
from selenium import webdriver
from test.common.page import Page
from time import sleep
from utils.config import Config
from test.page.pro3_gw_pages.kz_login_page import KZLoginPage

class CQApplocators(Page):

    weihu = (By.XPATH,"//*[contains(text(),'系统维护')]")
    xitongchongqi = (By.XPATH,"//*[contains(text(),'系统重启')]")
    chognqi = (By.XPATH,"//*[@id='restartBtn']")#//*[@id="restartBtn"]
    queding = (By.XPATH,"//html/body/div[2]/div[11]/div/button[1]/span")#/html/body/div[2]/div[11]/div/button[1]/span


    def enter_chognqi(self):
        try:
            self.find_element(*self.weihu).click()
            sleep(1)
            self.find_element(*self.xitongchongqi).click()
            sleep(1)
            self.find_element(*self.chognqi).click()
            sleep(1)
            self.find_element(*self.queding).click()
        except Exception as e:
            print('按钮未找到，原因%s' % e)


if __name__ == '__main__':
    URL = Config().get('URL_GW')
    page = KZLoginPage(browser_type='Chrome').get(URL, maximize_window=False)
    result = CQApplocators(page)
    result.enter_chognqi()