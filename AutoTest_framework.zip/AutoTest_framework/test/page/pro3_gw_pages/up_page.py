from selenium.webdriver.common.by import *
from selenium import webdriver
from test.common.page import Page
from time import sleep
from utils.config import Config
from test.page.kz_login_page import KZLoginPage


class UPApplocators(Page):
    goujian = (By.XPATH,"//*[contains(text(),'构件管理')]")#定位“构件管理”
    shengji = (By.XPATH,"//*[contains(text(),'产品升级')]")#定位产品升
    shengji_button =(By.XPATH,"//button[contains(text(),'管理模块升级')]")#定位“开始产品升级”按钮

    def enter_shengji(self):
        try:
            self.find_element(*self.goujian).click()
            sleep(1)
            self.find_element(*self.shengji).click()
            sleep(1)
            self.find_element(*self.shengji_button).click()
            sleep(1)
            self.switch_to_alert().accept()
        except Exception as e:
            print('按钮未找到，原因%s' % e)




if __name__ == '__main__':
    URL = Config().get('URL1')
    page = KZLoginPage(browser_type='Chrome').get(URL, maximize_window=False)
    result = UPApplocators(page)
    result.enter_shengji()
