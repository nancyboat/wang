from selenium.webdriver.common.by import *
from selenium import webdriver
from test.common.page import Page
from time import sleep
from utils.config import Config
from test.page.kz_login_page import KZLoginPage

class ZDApplocators(Page):

    zhenduan_1 = (By.XPATH,"//*[contains(text(),'系统诊断')]")
    zhenduan_2 = (By.XPATH,"//*[@id='ui-id-51']")#//*[@id="ui-id-51"]
    quanxuan = (By.XPATH,"//*[@id='content']/table/tbody/tr/td[1]/div/div[1]/input[1]")#//*[@id="content"]/table/tbody/tr/td[1]/div/div[1]/input[1]
    kaishi = (By.XPATH,"//*[@id='diagnose-button']")#//*[@id="diagnose-button"]


    def enter_zhenduan(self):
        try:
            self.find_element(*self.zhenduan_1).click()
            sleep(1)
            self.find_element(*self.zhenduan_2).click()
            sleep(1)
            self.find_element(*self.quanxuan).click()
            sleep(1)
            self.find_element(*self.kaishi).click()
        except Exception as e:
            print('按钮未找到，原因%s' % e)


if __name__ == '__main__':
    URL = Config().get('URL1')
    page = KZLoginPage(browser_type='Chrome').get(URL, maximize_window=False)
    result = ZDApplocators(page)
    result.enter_zhenduan()