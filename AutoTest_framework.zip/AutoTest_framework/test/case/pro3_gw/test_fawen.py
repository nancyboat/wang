import unittest
from utils.config import Config
from utils.log import logger
from test.page.fw_login_page import GWLoginPage
from test.page.fawen_page import FawenApplocators
from time import sleep

class FWCase(unittest.TestCase):
    URL = Config().get('URL')

    def sub_setUp(self):
        # 初始页面是main page，传入浏览器类型打开浏览器
        self.page = GWLoginPage().get(self.URL, maximize_window=False,implicitly_wait=20)

    def sub_tearDown(self):
        self.page.quit()

    def test_fawen_application(self):
        self.sub_setUp()
        self.page = GWLoginPage(self.page)
        self.page.userlogin()
        fawenapplocators = FawenApplocators(self.page)

        fawenapplocators.enter_bangong_button()
        sleep(3)
        fawenapplocators.enter_gwguanli_button()
        sleep(1)
        fawenapplocators.enter_xinzeng()
        sleep(1)
        fawenapplocators.enter_jtfawen()
        sleep(3)
        fawenapplocators.enter_biaoti()
        sleep(1)
        fawenapplocators.enter_zhudw()
        sleep(1)
        fawenapplocators.enter_chaodw()
        sleep(1)
        # fawenapplocators.enter_people()
        # sleep(1)
        fawenapplocators.enter_tijiao_button()
        sleep(6)
        fawenapplocators.enter_fwguanli_button()
        sleep(1)
        fawenapplocators.enter_lianjie()
        sleep(3)
        fawenapplocators.enter_shenpi_button()
        sleep(2)
        fawenapplocators.enter_qdtijiao_button()
        sleep(6)
        fawenapplocators.enter_lianjie()
        sleep(10)
        fawenapplocators.enter_xuanze()
        sleep(2)
        fawenapplocators.enter_dangan()
        sleep(1)
        fawenapplocators.enter_qdtijiao_button()
        sleep(1)
        fawenapplocators.enter_shenpi_button()
        sleep(2)
        fawenapplocators.enter_qdtijiao_button()
        sleep(1)

if __name__ == '__main__':
    unittest.main()