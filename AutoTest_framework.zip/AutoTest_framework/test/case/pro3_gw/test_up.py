import unittest
from utils.config import Config
from utils.log import logger
from test.page.kz_login_page import KZLoginPage
from test.page.up_page import UPApplocators
from time import sleep

class FWCase(unittest.TestCase):
    URL = Config().get('URL1')

    def sub_setUp(self):
        # 初始页面是main page，传入浏览器类型打开浏览器
        self.page = KZLoginPage().get(self.URL, maximize_window=False,implicitly_wait=20)

    def sub_tearDown(self):
        self.page.quit()

    def test_fawen_application(self):
        self.sub_setUp()
        self.page = KZLoginPage(self.page)
        upapplocators = UPApplocators(self.page)

        upapplocators.enter_shengji()
        sleep(100)


if __name__ == '__main__':
    unittest.main()