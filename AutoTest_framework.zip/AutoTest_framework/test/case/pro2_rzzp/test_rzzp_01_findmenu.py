import unittest
from utils.log import logger
from test.page.pro2_rzzp_pages.rzzp_login_page import RZZPLoginPage, MenuLocators
from utils.config import Config
from time import sleep

class RZZP_Case(unittest.TestCase):
    """
    人资招聘单元测试
    """
    URL = Config().get('URL_RZZP')
    def sub_setUp(self):
        # 初始页面是main page，传入浏览器类型打开浏览器
        self.page = RZZPLoginPage().get(self.URL, maximize_window=False)

    def sub_tearDown(self):
        self.page.quit()

    #@unittest.skip('test')
    def test_01_rzzplogin(self):

        '''用例1：检查招聘系统登录是否成功'''
        self.sub_setUp()
        logger.info('********打开谷歌浏览器********')
        self.page = RZZPLoginPage(self.page)
        logger.info('********同望科技人资招聘系统登录********')
        self.page.userlogin()
        sleep(1)
        logger.info('********输入用户名和密码登录********')
        sleep(5)
        ele = self.page.get_login_name()
        self.assertIn("欢迎您",ele)
        self.sub_tearDown()

    # @unittest.skip('test')
    def test_02_rzzpmenu(self):

        """用例2：检查招聘系统下的简历菜单是否完整"""
        self.sub_setUp()
        self.page = RZZPLoginPage(self.page)
        self.page.userlogin()
        sleep(5)
        pageresult = MenuLocators(self.page)
        sleep(3)
        mark = pageresult.menu_butten()
        self.assertEqual(1, mark)
        self.sub_tearDown()

if __name__ =='__main__':
    unittest.main()




