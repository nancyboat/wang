import unittest

from test.page.pro2_rzzp_pages.rzzp_login_page import RZZPLoginPage, MenuLocators
from utils.config import Config


class RZZP_Case(unittest.TestCase):
    """
    人资招聘单元测试
    """
    URL = Config().get('URL_RZZP')

    def sub_setUp(self):
        # 初始页面是main page，传入浏览器类型打开浏览器
        self.page = RZZPLoginPage().get(self.URL, maximize_window=False,implicitly_wait=20)

    def sub_tearDown(self):
        self.page.quit()

    def test_01_rzzplogin(self):
        '''用例1：检查招聘系统登录是否成功'''
        self.sub_setUp()
        self.page = RZZPLoginPage(self.page)
        self.page.userlogin()
        ele = self.page.get_login_name()
        print(ele)
        self.assertIn("欢迎您",ele)

    def test_02_rzzpmenu(self):
        '''用例2：检查招聘系统下的简历菜单是否完整'''
        self.sub_setUp()
        self.page = RZZPLoginPage(self.page)
        self.page.userlogin()
        pageresult= MenuLocators(self.page)
        mark = pageresult.menu_butten()
        self.assertEqual(1,mark)

if __name__ =='__main__':
    unittest.main()