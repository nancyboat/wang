import unittest
from utils.mail import Email
from test.page.pro1_rz_pages.rz_login_page import RZLoginPage
from utils.HTMLTestRunner_PY3 import HTMLTestRunner
from utils.config import Config, DATA_PATH, REPORT_PATH
from utils.file_reader import ExcelReader
from utils.log import logger
from time import sleep

class TestRenZi(unittest.TestCase):
    URL = Config().get('URL_RZ')
    excel = DATA_PATH + '/renzi.xlsx'

    def sub_setUp(self):
        # 初始页面是main page，传入浏览器类型打开浏览器
        self.page = RZLoginPage(browser_type='Chrome').get(self.URL, maximize_window=False)
        self.page.tenantuserlogin()

    def sub_tearDown(self):
        self.page.quit()

    def test_login(self):
        datas = ExcelReader(self.excel).data
        for d in datas:
            with self.subTest(data=d):
                self.sub_setUp()
                self.page.userlogin(d['username'],d['password'])
                sleep(1)
                self.page = RZLoginPage(self.page) # 页面跳转到result page
                loginname = self.page.result_name()
                target_value = d['target_value']
                self.assertIn(target_value, loginname)
                self.sub_tearDown()

if __name__ == '__main__':
    #unittest.main()
    report = REPORT_PATH + '\\report.html'
    with open(report, 'wb') as f:
        runner = HTMLTestRunner(f, verbosity=2, title='人资登录功能测试', description='对人资登录进行数据驱动测试')
        runner.run(TestRenZi('test_login'))

    # e = Email(title='测试报告',
    #           message='这是今天的同望人资系统-登录测试用例-测试报告，请查收！',
    #           receiver='wangls@toone.com.cn',
    #           server='smtp.qq.com',
    #           sender='505413880@qq.com',
    #           password='birpftturyjvbidd',
    #           path=report
    #           )
    # e.send()