import unittest
from utils.config import Config
from utils.log import logger
from test.page.pro1_rz_pages.rz_login_page import RZLoginPage
from test.page.pro1_rz_pages.rz_dd_page import DdAppLocators
from time import sleep

class RZCase(unittest.TestCase):
    URL = Config().get('URL_RZ')

    def sub_setUp(self):
        # 初始页面是main page，传入浏览器类型打开浏览器
        self.page = RZLoginPage(browser_type='Chrome').get(self.URL, maximize_window=False)

    def sub_tearDown(self):
        self.page.quit()

    def test_05_dd_application(self):
        """调动申请单元测试"""
        self.sub_setUp()
        self.page = RZLoginPage(self.page)
        sleep(1)
        self.page.tenantuserlogin()
        sleep(2)
        self.page.userlogin('dengb',8)
        sleep(1)
        loginname = self.page.result_name()
        if "欢迎您" in loginname:
            ddapplication = DdAppLocators(self.page)
            sleep(2)
            ddapplication.enter_dd_button()
            sleep(3)
            ddapplication.enter_dd_bumen()
            sleep(3)
            ddapplication.enter_choose_bumen()
            sleep(3)
            ddapplication.enter_dd_zhiwei()
            sleep(2)
            ddapplication.enter_choose_zhiwei()
            sleep(2)
            ddapplication.enter_dd_reasons()
            sleep(2)
            ddapplication.enter_dd_things()
            sleep(2)
            ddapplication.enter_jiaojie()
            sleep(2)
            ddapplication.enter_dd_submit()
            sleep(2)
            ele = ddapplication.enter_dd_submit_content()
            self.assertIn('草稿', ele)
            self.sub_tearDown()
        else:
            self.assertIn('登录不成功', loginname)

if __name__ == '__main__':
    unittest.main()