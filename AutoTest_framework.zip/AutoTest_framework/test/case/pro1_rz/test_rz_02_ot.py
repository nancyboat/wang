import unittest
from time import sleep

from test.page.pro1_rz_pages.rz_login_page import RZLoginPage
from test.page.pro1_rz_pages.rz_ot_page import OtAppLocators
from utils.config import Config


class RZCase(unittest.TestCase):
    URL = Config().get('URL_RZ')

    def sub_setUp(self):
        # 初始页面是main page，传入浏览器类型打开浏览器
        self.page = RZLoginPage().get(self.URL, maximize_window=False)

    def sub_tearDown(self):
        self.page.quit()

    def test_02_ot_application(self):
        """加班申请单元测试"""
        self.sub_setUp()
        self.page = RZLoginPage(self.page)
        sleep(1)
        self.page.tenantuserlogin()
        sleep(2)
        self.page.userlogin('liuf',8)
        loginname = self.page.result_name()
        if "欢迎您" in loginname:
            otapplication = OtAppLocators(self.page)
            sleep(1)
            otapplication.enter_ot_butten()
            sleep(2)
            otapplication.enter_ot_type()
            sleep(2)
            otapplication.enter_ot_place()
            sleep(2)
            otapplication.enter_ot_reason()
            sleep(2)
            otapplication.enter_date_time()
            ele = otapplication.sucess_content
            self.assertIn('提交成功', ele)
            self.sub_tearDown()
        else:
            self.assertIn('登录不成功',loginname)

if __name__ == '__main__':
    unittest.main()