import unittest
from time import sleep

from test.page.pro1_rz_pages.rz_login_page import RZLoginPage
from test.page.pro1_rz_pages.rz_travel_page import TravelAppLocators
from utils.config import Config


class RZCase(unittest.TestCase):
    URL = Config().get('URL_RZ')

    def sub_setUp(self):
        # 初始页面是main page，传入浏览器类型打开浏览器
        self.page = RZLoginPage().get(self.URL, maximize_window=False)

    def sub_tearDown(self):
        self.page.quit()

    def test_03_travel_application(self):
        """出差申请单元测试"""
        self.sub_setUp()
        self.page = RZLoginPage(self.page)
        sleep(1)
        self.page.tenantuserlogin()
        sleep(2)
        self.page.userlogin('caihr',8)
        sleep(1)
        loginname = self.page.result_name()
        if "欢迎您" in loginname:
            travelapplication = TravelAppLocators(self.page)
            sleep(1)
            travelapplication.enter_travel_butten()
            sleep(6)
            travelapplication.enter_travel_reason()
            sleep(3)
            travelapplication.enter_travel_place()
            sleep(1)
            travelapplication.enter_date_time()
            sleep(1)
            ele = travelapplication.sucess_content
            self.assertIn('提交成功', ele)
            self.sub_tearDown()
        else:
            self.assertIn('登录不成功', loginname)

if __name__ == '__main__':
    unittest.main()