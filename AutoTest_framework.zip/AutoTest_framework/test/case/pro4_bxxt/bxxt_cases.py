import unittest
from utils.log import logger
from test.page.pro4_bxxt_pages.bxxt_login_page import BXLoginPage
from test.page.pro4_bxxt_pages.bxxt_baoxiao_page import BaoXiaoAppLocators
from utils.config import Config
from time import sleep


class CLBX_Case(unittest.TestCase):
    """
    报销系统差旅报销单元测试
    """
    URL = Config().get('URL_BX')

    def sub_setUp(self):
        # 初始页面是main page，传入浏览器类型打开浏览器
        self.page = BXLoginPage().get(self.URL, maximize_window=False)

    def sub_tearDown(self):
        self.page.quit()

    # @unittest.skip('test')
    def test_01_baoxiaologin(self):
        """用例1：同望租户登录系统，用户登录，判断登录成功用例成功；否则用例失败"""
        self.sub_setUp()
        logger.info('********打开谷歌浏览器********')
        self.page = BXLoginPage(self.page)
        logger.info('********选择同望科技租户登录********')
        self.page.tenantuserlogin()
        logger.info('********同望科技报销系统登录********')
        sleep(2)
        self.page.userlogin()
        sleep(1)
        logger.info('********输入用户名和密码登录********')
        sleep(5)
        ele = self.page.get_login_name()
        print(ele)
        self.assertIn("欢迎您", ele)
        self.sub_tearDown()

    # @unittest.skip('test')
    def test_02_clbx(self):
        """用例2:登录用户-点击差旅报销，输入费用明细，校验报销合计总数是否达到预期，达到成功；否则用例失败"""
        self.sub_setUp()
        self.page = BXLoginPage(self.page)
        self.page.tenantuserlogin()
        sleep(2)
        self.page.userlogin()
        sleep(2)
        loginname = self.page.result_name()
        if "欢迎您" in loginname:
            self.page = BaoXiaoAppLocators(self.page)
            sleep(2)
            self.page.enter_baoxiao_button()
            sleep(5)
            self.page.enter_chailv_button()
            sleep(8)
            self.page.enter_leave_reason()
            sleep(2)
            self.page.enter_happen_date()
            sleep(2)
            self.page.enter_start_Place()
            sleep(2)
            self.page.enter_arrive_Place()
            sleep(2)
            self.page.enter_travel_Expense()
            sleep(2)
            self.page.enter_hotel_Expense()
            sleep(2)
            self.page.enter_other_Expense()
            sleep(2)
            self.page.enter_costExplain()
            sleep(2)
            self.page.print_result()
            self.assertIn('670', self.page.get_count())
            print('预期输出670，用例成功')
            self.sub_tearDown()
        else:
            self.assertIn('登录不成功', loginname)

    # @unittest.skip('test')
    def test_03_clbx(self):
        """用例3：单据填报完成提交，提交成功用例成功；提交报错用例失败，把错误信息反馈到报告里"""
        self.sub_setUp()
        self.page = BXLoginPage(self.page)
        self.page.tenantuserlogin()
        sleep(2)
        self.page.userlogin()
        sleep(2)
        loginname = self.page.result_name()
        if "欢迎您" in loginname:
            self.page = BaoXiaoAppLocators(self.page)
            sleep(2)
            self.page.enter_baoxiao_button()
            sleep(5)
            self.page.enter_chailv_button()
            sleep(8)
            self.page.enter_leave_reason()
            #sleep(2)
            self.page.enter_happen_date()
            #sleep(2)
            self.page.enter_start_Place()
            #sleep(2)
            self.page.enter_arrive_Place()
            #sleep(2)
            self.page.enter_travel_Expense()
            #sleep(2)
            self.page.enter_hotel_Expense()
            #sleep(2)
            self.page.enter_other_Expense()
            #sleep(2)
            self.page.enter_costExplain()
            #sleep(2)
            self.page.enter_Submit()
        else:
            self.assertIn('登录不成功', loginname)



if __name__ == '__main__':
    unittest.main()

