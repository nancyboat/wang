from utils.config import Config
import pymssql
from utils.log import logger

#读取config.yaml里的数据库设置信息，由于用YamlReader读取返回的是一个list
#因此需要通过索引获取对应的value值
db = Config().get('DATABASES')
server = db.get('host')
user = db.get('username')
password = db.get('password')
database = db.get('database')
port = db.get('port')
charset = db.get('charset')
#把数据库参数设置成字典，传入到链接数据库
config = {
            'host': str(server),
            'user': user,
            'password': password,
            'port': int(port),
            'database': database,
            'charset': charset
        }

class DB:
    def __init__(self):
        self.logger = logger

    def connetDB(self):
        '''连接sqlserver并获取游标指针，捕获连接失败异常'''
        try:
            self.conn = pymssql.connect(**config)#
            self.cursor = self.conn.cursor()
            print("Connect DB successfully!")
        except ConnectionError as e:
            self.logger.error(e)
        return self.cursor

    def executeSQL(self,sql):
        ''' 执行查询语句'''
        cur = self.connetDB()#建立链接并创建数据库操作指针
        cur.execute(sql)#通过指针来执行sql指令
        reslist = cur.fetchall()#通过指针来获取sql指令响应数据
        cur.close()#游标指标关闭
        self.conn.close()#查询完毕后必须关闭连接
        return reslist

    def executeNonQuery(self,sql):
        ''' 执行非查询语句写入数据，或者创建表，数据库等'''
        cur = self.connetDB()
        cur.execute(sql)
        self.conn.commit()#连接句柄来提交
        print('change db ok!')
        cur.close()
        self.conn.close()

if __name__ =="__main__":
    #sql = "select * from yzzx_client_baseInfo where id = '483784904eb0048f0ed38a822850087n'"
    sql = "select * from bs_mt_code"
    reslist = DB().executeSQL(sql)
    for i in reslist:
        print(i[0])

    # 注意:在进行插入操作时,自增长度不能够写入
    # sql = '''insert into yzzx_client_baseInfo
    #    (
    #         id,
    #        clientName,
    #        sex,
    #        mobile,
    #        clientType
    #    )
    #    VALUES
    #    (
    #
    #        '483784904eb0048f0ed38a822850087m','autotest', '男', '7777', '潜在客户'
    #    );
    #
    #    '''
    # reslist = DB()
    # reslist.executeNonQuery(sql)