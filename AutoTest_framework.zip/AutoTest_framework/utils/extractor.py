"""抽取器，从响应结果中抽取部门数据"""
import json
