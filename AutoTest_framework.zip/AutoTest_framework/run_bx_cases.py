﻿import sys
sys.path.append('C:\\Program Files (x86)\\Jenkins\workspace\\报销系统自动化脚本\\AutoTest_framework\\utils')
import unittest
from utils.config import CASE_PATH,REPORT_PATH
from utils.HTMLTestRunner_PY3 import HTMLTestRunner
from utils.mail import Email

class RunTools:
    def chooseDirCases(self,casedir,pattern):
        '''
        根据指定目录获取匹配的测试用例
        :param casedir:测试用例目录路径
        :param pattern:匹配模式
        :return:测试用例集
        '''
        discover_cases = unittest.defaultTestLoader.discover(casedir,pattern=pattern)
        return discover_cases

if __name__ == '__main__':
    casepath = CASE_PATH +'\\pro4_bxxt'
    #print(casepath)
    report = REPORT_PATH  +'\\pro4_bxxt_report'+'\\report.html'
    runtools = RunTools()
    all_cases = runtools.chooseDirCases(casepath, 'bxxt_cases.py')
    #print(all_cases)
    with open(report, 'wb') as f:
        runner = HTMLTestRunner(f, verbosity=2, title='同望报销系统', description='所有测试情况')
        runner.run(all_cases)
    e = Email(title='测试报告',
              message='这是今天的同望报销系统测试报告，请查收！',
              receiver='wangls@toone.com.cn;liuyf@toone.com.cn;wangting@toone.com.cn',
              server='smtp.qq.com',
              sender='505413880@qq.com',
              password='birpftturyjvbidd',
              path=report
              )
    e.send()